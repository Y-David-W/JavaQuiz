
/*
* El archivo tiene que estar en la carpeta de default, te va a avisar si no funciona y donde necesitas
* colocar el archivo
*
* */
package concursodeexamenes;
import concursodeexamenes.BD.BaseDatos;
import concursodeexamenes.funciones.ServicioJuego;
/*
* ..\preguntas_PROG.txt
* */
import java.util.Scanner;
/**
 *
 * @author Dav
 */
public class Main {
    public static void main(String[] args) {

        Scanner teclado = new Scanner(System.in);
        ServicioJuego juego = new ServicioJuego();
        BaseDatos baseDatos = new BaseDatos();

        int opcion = 0;
        do {
            System.out.println("┌───────────────────────────────────────┐");
            System.out.println("│           MENÚ PRINCIPAL              │");
            System.out.println("├───────────────────────────────────────┤");
            System.out.println("│ 1. Configuración del sistema          │");
            System.out.println("│ 2. Jugar partida                      │");
            System.out.println("│ 3. Ver ranking                        │");
            System.out.println("│ 4. Salir                              │");
            System.out.println("└───────────────────────────────────────┘");
            System.out.print("Selecciona una opción: ");

            try {
                opcion = Integer.parseInt(teclado.nextLine());

                switch (opcion) {
                    case 1 -> mostrarMenuConfiguracion(teclado, baseDatos);
                    case 2 -> juego.jugarPartida(teclado);
                    case 3->{
                        juego.mostrarRanking(teclado);
                    }
                    case 4->
                            System.out.println("Gracias por jugar, ¡hasta la próxima!");

                    default->
                            System.out.println("Opción no válida.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Por favor, introduce un número válido.");
            }
        } while (opcion != 4);
        teclado.close();
    }
    private static void mostrarMenuConfiguracion(Scanner teclado, BaseDatos baseDatos) {
        int opcion;
        do {
            System.out.println("┌────────────────────────────────────────────┐");
            System.out.println("│         CONFIGURACIÓN DEL SISTEMA          │");
            System.out.println("├────────────────────────────────────────────┤");
            System.out.println("│ 1. Cargar preguntas                        │");
            System.out.println("│ 2. Reiniciar juego                         │");
            System.out.println("│ 3. Borrar preguntas                        │");
            System.out.println("│ 4. Volver al menú principal                │");
            System.out.println("└────────────────────────────────────────────┘");
            System.out.print("Seleccione una opción: ");

            try {
                opcion = Integer.parseInt(teclado.nextLine());
                switch (opcion) {
                    case 1:
                        System.out.println("┌────────────────────────────────────────────┐");
                        System.out.println("│             Cargando preguntas             │");
                        System.out.println("└────────────────────────────────────────────┘");
                        System.out.print("Introduce el nombre del modulo: ");
                        String nombre_modulo = teclado.nextLine();

                        System.out.print("Introduce la ruta del fichero: ");
                        String ruta = teclado.nextLine();

                        baseDatos.cargarPreguntasDesdeFichero(ruta, nombre_modulo);
                        break;
                    case 2:
                        baseDatos.reiniciarJuego();
                        break;
                    case 3:
                        baseDatos.borrarPreguntas();
                        break;
                    case 4:
                        return;
                    default:
                        System.out.println("La opción no es válida.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Por favor, introduce un número válido.");
            }
        } while (true);    }
}
