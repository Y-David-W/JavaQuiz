package concursodeexamenes.BD;

import concursodeexamenes.funciones.PreguntaDAO;
import java.io.*;
import java.nio.file.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.sql.*;
import java.util.*;


public class BaseDatos {
    public static void cargarPreguntasDesdeFichero(String ruta, String nombre_modulo) {
        PreguntaDAO dao = new PreguntaDAO();
        int contador = 0;

        try (BufferedReader br = new BufferedReader(new FileReader(ruta))) {
            String linea;
            while ((linea = br.readLine()) != null) {

                // Saltar comentarios o líneas vacías
                if (linea.trim().isEmpty() || linea.trim().startsWith("//")) {
                    continue;
                }

                String encabezado = linea.trim();

                // Leer las siguientes 4 líneas (respuestas)
                String correcta = br.readLine();
                String incorrecta1 = br.readLine();
                String incorrecta2 = br.readLine();
                String incorrecta3 = br.readLine();

                if (correcta == null || incorrecta1 == null || incorrecta2 == null || incorrecta3 == null) {
                    System.out.println("Error: pregunta incompleta en el archivo, recuerda terminar con .txt.");
                    break;
                }

                // Extrae el numero y unidad
                if (encabezado.length() < 5 || !Character.isDigit(encabezado.charAt(0))) {
                    System.out.println("Formato inválido en línea: " + encabezado);
                    continue;
                }
                // Lógica al cargar los .txt
                String modulo = nombre_modulo;
                String numero = encabezado.substring(2, 4);
                String unidad = encabezado.substring(0, 2);
                String enunciado = encabezado.substring(5).trim(); // después de los 4 dígitos y un espacio

                Pregunta pregunta = new Pregunta(modulo, unidad, numero, enunciado,
                        correcta.trim(), incorrecta1.trim(), incorrecta2.trim(), incorrecta3.trim());

                dao.insertarPregunta(pregunta);
                contador++;
            }

            System.out.println("Se cargaron " + contador + " preguntas correctamente.");
        } catch (IOException e) {
            System.out.println("Error al leer el archivo: " + e.getMessage());
        }
    }
    public void reiniciarJuego() {
        System.out.println("┌────────────────────────────────────────────┐");
        System.out.println("│             Reiniciando juego              │");
        System.out.println("└────────────────────────────────────────────┘");
        String nombreArchivo = "puntuacion.txt";
        Map<String, Integer> puntuacionesFinales = new LinkedHashMap<>();
        Path archivo = Paths.get(nombreArchivo);

        // Leer archivo y cargar puntuaciones actuales (ignorando la primera línea)
        if (Files.exists(archivo)) {
            try (BufferedReader br = Files.newBufferedReader(archivo)) {
                String linea;
                boolean primeraLinea = true;

                while ((linea = br.readLine()) != null) {
                    if (primeraLinea) {
                        primeraLinea = false;
                        continue; // saltamos la fecha
                    }

                    linea = linea.trim();
                    if (linea.isEmpty()) continue;

                    String[] partes = linea.split(" ");
                    if (partes.length >= 2) {
                        String nombre = partes[0];
                        try {
                            int puntos = Integer.parseInt(partes[1]);
                            puntuacionesFinales.put(nombre, puntos);
                        } catch (NumberFormatException ignored) {}
                    }
                }
            } catch (IOException e) {
                System.out.println("Error leyendo el archivo: " + e.getMessage());
                return;
            }
        }

        // Leer puntuaciones desde base de datos y actualizar si mejora
        try (Connection conn = ConexionBD.conectar()) {
            String sql = "SELECT nombre, puntuacion FROM usuarios";
            try (PreparedStatement ps = conn.prepareStatement(sql);
                 ResultSet rs = ps.executeQuery()) {

                while (rs.next()) {
                    String nombre = rs.getString("nombre");
                    int puntos = rs.getInt("puntuacion");

                    // Guardar la mejor puntuación
                    puntuacionesFinales.merge(nombre, puntos, Math::max);
                }

            } catch (SQLException e) {
                System.out.println("Error leyendo desde la base de datos: " + e.getMessage());
                return;
            }

            // Ordenar las puntuaciones de menor a mayor
            List<Map.Entry<String, Integer>> ordenadas = new ArrayList<>(puntuacionesFinales.entrySet());
            ordenadas.sort(Map.Entry.comparingByValue()); // menor a mayor

            // Escribir al archivo
            try {
                List<String> contenidoFinal = new ArrayList<>();

                // Fecha actual
                LocalDateTime ahora = LocalDateTime.now();
                DateTimeFormatter formato = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
                contenidoFinal.add(ahora.format(formato));

                // Añadir líneas ordenadas
                for (Map.Entry<String, Integer> entry : ordenadas) {
                    contenidoFinal.add(entry.getKey() + " " + entry.getValue());
                }

                Files.write(archivo, contenidoFinal, StandardOpenOption.WRITE, StandardOpenOption.TRUNCATE_EXISTING);
                System.out.println("Archivo actualizado con puntuaciones ordenadas.");

            } catch (IOException e) {
                System.out.println("Error escribiendo el archivo: " + e.getMessage());
            }

            // Vaciar la tabla usuarios
            try (Statement stmt = conn.createStatement()) {
                stmt.executeUpdate("DELETE FROM usuarios");
                System.out.println("Tabla 'usuarios' vaciada.");
            } catch (SQLException e) {
                System.out.println("Error al vaciar la tabla: " + e.getMessage());
            }

        } catch (SQLException e) {
            System.out.println("Error de conexión a la base de datos: " + e.getMessage());
        }
    }


    public void borrarPreguntas() {

        // Borra las preguntas, para ello conecta al base de dato y ejecuta una sentencia para borrar
        System.out.println("┌────────────────────────────────────────────┐");
        System.out.println("│             Borrando preguntas             │");
        System.out.println("└────────────────────────────────────────────┘");
        try (java.sql.Connection conn = ConexionBD.conectar();
             java.sql.Statement stmt = conn.createStatement()) {

            stmt.executeUpdate("DELETE FROM pregunta"); // Asegúrate de que esta tabla existe
            System.out.println("Las preguntas se ha borrado correctamente");

        } catch (java.sql.SQLException e) {
            System.out.println("Error al borrar: " + e.getMessage());
        }
    }
}