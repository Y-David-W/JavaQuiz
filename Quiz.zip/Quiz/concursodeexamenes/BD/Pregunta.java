package concursodeexamenes.BD;

public class Pregunta {
    private String modulo;
    private String unidad;
    private String numero;
    private String enunciado;
    private String correcta;
    private String incorrecta1;
    private String incorrecta2;
    private String incorrecta3;

    public Pregunta(String modulo, String unidad, String numero, String enunciado,
                    String correcta, String incorrecta1, String incorrecta2, String incorrecta3) {
        this.modulo = modulo;
        this.unidad = unidad;
        this.numero = numero;
        this.enunciado = enunciado;
        this.correcta = correcta;
        this.incorrecta1 = incorrecta1;
        this.incorrecta2 = incorrecta2;
        this.incorrecta3 = incorrecta3;
    }

    public String getModulo() { return modulo; }
    public String getUnidad() { return unidad; }
    public String getNumero() { return numero; }
    public String getEnunciado() { return enunciado; }
    public String getCorrecta() { return correcta; }
    public String getIncorrecta1() { return incorrecta1; }
    public String getIncorrecta2() { return incorrecta2; }
    public String getIncorrecta3() { return incorrecta3; }
}
