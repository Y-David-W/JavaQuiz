package concursodeexamenes.BD;

import java.io.*;
import java.util.*;

public class GestorDePunto {
    private static final String ARCHIVO = "puntuacion.txt";

    public static void guardarPuntuacion(String nombre, int puntuacion) {
        Map<String, Integer> puntuaciones = new LinkedHashMap<>();

        File archivo = new File(ARCHIVO);
        if (archivo.exists()) {
            try (BufferedReader br = new BufferedReader(new FileReader(archivo))) {
                String linea;
                while ((linea = br.readLine()) != null) {
                    String[] partes = linea.split("puntuacion:");
                    if (partes.length == 2) {
                        String user = partes[0].replace("nombre:", "").trim();
                        int puntos = Integer.parseInt(partes[1].trim());
                        puntuaciones.put(user, puntos);
                    }
                }
            } catch (IOException e) {
                System.err.println("Error leyendo puntuacion.txt: " + e.getMessage());
            }
        }

        // Actualizar solo si la nueva puntuación es mayor
        if (!puntuaciones.containsKey(nombre) || puntuacion > puntuaciones.get(nombre)) {
            puntuaciones.put(nombre, puntuacion);
        }

        // Escribir de nuevo todo en el formato especificado
        try (PrintWriter pw = new PrintWriter(new FileWriter(ARCHIVO))) {
            for (Map.Entry<String, Integer> entry : puntuaciones.entrySet()) {
                pw.println("nombre: " + entry.getKey() + " puntuacion: " + entry.getValue());
            }
        } catch (IOException e) {
            System.err.println("Error escribiendo puntuacion.txt: " + e.getMessage());
        }
    }
}

