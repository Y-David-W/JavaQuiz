package concursodeexamenes.funciones;

import concursodeexamenes.BD.ConexionBD;
import concursodeexamenes.BD.Pregunta;
import java.io.BufferedReader;
import java.io.IOException;
import java.nio.file.*;
import java.util.*;

public class ServicioJuego {
    private final PreguntaDAO preguntaDAO = new PreguntaDAO();
    private final Scanner sc = new Scanner(System.in);



    public void jugarPartida(Scanner sc) {
        // Crear tabla si no existe
        preguntaDAO.crearTabla();

        // Datos del jugador
        System.out.println("┌────────────────────────────────────────────┐");
        System.out.println("│             Jugando partida                │");
        System.out.println("└────────────────────────────────────────────┘");

        String nombre = "";
        String modulo = "";
        int unidad = 0;

        // Validación del nombre
        while (nombre.trim().isEmpty()) {
            try {
                System.out.print("Nombre de usuario: ");
                nombre = sc.nextLine().trim();
                if (nombre.isEmpty()) {
                    throw new IllegalArgumentException("El nombre no puede estar vacío");
                }
            } catch (IllegalArgumentException e) {
                System.out.println("Error: " + e.getMessage());
            } catch (Exception e) {
                System.out.println("Error inesperado al leer el nombre");
            }
        }

        // Validación del módulo
        boolean moduloValido = false;
        while (!moduloValido) {
            try {
                System.out.print("Módulo (PROG o ALEATORIO): ");
                modulo = sc.nextLine().toUpperCase().trim();
                moduloValido = true;
            } catch (IllegalArgumentException e) {
                System.out.println("Error: " + e.getMessage());
            } catch (Exception e) {
                System.out.println("Error inesperado al leer el módulo");
            }
        }

        // Validación de la unidad
        boolean unidadValida = false;
        while (!unidadValida) {
            try {
                System.out.print("Unidad (0 para aleatorio): ");
                String unidadStr = sc.nextLine().trim();
                unidad = Integer.parseInt(unidadStr);
                if (unidad < 0) {
                    throw new IllegalArgumentException("La unidad no puede ser negativa");
                }
                unidadValida = true;
            } catch (NumberFormatException e) {
                System.out.println("Error: Debes introducir un número válido");
            } catch (IllegalArgumentException e) {
                System.out.println("Error: " + e.getMessage());
            } catch (Exception e) {
                System.out.println("Error inesperado al leer la unidad");
            }
        }

        // Obtener preguntas filtradas
        List<Pregunta> preguntas = obtenerPreguntas(modulo, unidad);
        if (preguntas.isEmpty()) {
            System.out.println("No hay preguntas disponibles. Asegúrate de cargarlas primero.");
            return;
        }
        Collections.shuffle(preguntas);

        // Juego
        int puntuacion = 0;
        for (int i = 0; i < Math.min(5, preguntas.size()); i++) {
            Pregunta p = preguntas.get(i);

            List<String> opciones = new ArrayList<>();
            opciones.add(p.getCorrecta());
            opciones.add(p.getIncorrecta1());
            opciones.add(p.getIncorrecta2());
            opciones.add(p.getIncorrecta3());
            Collections.shuffle(opciones);
            System.out.println("\n" + "Pregunta número "+ (i+1) +"/"+ 5);
            System.out.println(p.getEnunciado());
            for (int j = 0; j < opciones.size(); j++) {
                System.out.println((j + 1) + ". " + opciones.get(j));
            }

            System.out.print("Tu respuesta: ");
            int respuesta;
            try {
                respuesta = Integer.parseInt(sc.nextLine());
                if (respuesta < 1 || respuesta > 4) throw new NumberFormatException();
            } catch (NumberFormatException e) {
                System.out.println("Respuesta inválida. Se contará como incorrecta.");
                continue;
            }

            if (opciones.get(respuesta - 1).equals(p.getCorrecta())) {
                System.out.println("¡Correcto!");
                puntuacion += 10;
            } else {
                System.out.println("Incorrecto. Respuesta correcta: " + p.getCorrecta());
            }
        }

        // Guardar puntuación

        try (java.sql.Connection conn = ConexionBD.conectar();
             java.sql.PreparedStatement stmt = conn.prepareStatement(
                     "INSERT INTO usuarios (nombre, puntuacion) VALUES (?, ?) " +
                             "ON DUPLICATE KEY UPDATE puntuacion = GREATEST(puntuacion, VALUES(puntuacion))"
             )) {

            stmt.setString(1, nombre);
            stmt.setInt(2, puntuacion);
            stmt.executeUpdate();
        System.out.println("Guardado en el base de dato correctamente");
        } catch (java.sql.SQLException e) {
            System.out.println("Error al insertar o actualizar usuario: " + e.getMessage());
        }

        System.out.println( nombre +" has obtenido " + puntuacion + " puntos.");
    }

    private List<Pregunta> obtenerPreguntas(String modulo, int unidad) {

        List<Pregunta> todas = preguntaDAO.obtenerTodas();
        List<Pregunta> filtradas = new ArrayList<>();
        for (Pregunta p : todas) {
            boolean moduloOK = modulo.equals("ALEATORIO") || p.getModulo().equalsIgnoreCase(modulo);
            boolean unidadOK = unidad == 0 || Integer.parseInt(p.getUnidad()) == unidad;
            if (moduloOK && unidadOK) filtradas.add(p);
        }
        return filtradas;
    }

    public void mostrarRanking(Scanner scanner) {
        String nombreArchivo = "puntuacion.txt";
        Path archivo = Paths.get(nombreArchivo);

        if (!Files.exists(archivo)) {
            System.out.println("El archivo de puntuación no existe.");
            return;
        }

        String fecha = "";
        Map<String, Integer> puntuaciones = new LinkedHashMap<>();

        try (BufferedReader br = Files.newBufferedReader(archivo)) {
            String linea;
            boolean primeraLinea = true;

            while ((linea = br.readLine()) != null) {
                linea = linea.trim();
                if (linea.isEmpty()) continue;

                if (primeraLinea) {
                    fecha = linea;
                    primeraLinea = false;
                    continue;
                }

                String[] partes = linea.split(" ");
                if (partes.length >= 2) {
                    String nombre = partes[0];
                    try {
                        int puntos = Integer.parseInt(partes[1]);
                        puntuaciones.put(nombre, puntos);
                    } catch (NumberFormatException ignored) {}
                }
            }
        } catch (IOException e) {
            System.out.println("Error leyendo el archivo: " + e.getMessage());
            return;
        }

        System.out.print("¿Deseas ver el ranking en orden ascendente o descendente? (asc/desc): ");
        String orden = scanner.nextLine().trim().toLowerCase();

        List<Map.Entry<String, Integer>> listaOrdenada = new ArrayList<>(puntuaciones.entrySet());
        if (orden.equals("desc")) {
            listaOrdenada.sort(Map.Entry.<String, Integer>comparingByValue().reversed());
        } else {
            listaOrdenada.sort(Map.Entry.comparingByValue());
        }

        // Mostrar resultados
        System.out.println("\nÚltimo reinicio: " + fecha);
        System.out.println("Ranking de jugadores:");
        for (Map.Entry<String, Integer> entry : listaOrdenada) {
            System.out.println(entry.getKey() + ": " + entry.getValue());
        }
    }
}