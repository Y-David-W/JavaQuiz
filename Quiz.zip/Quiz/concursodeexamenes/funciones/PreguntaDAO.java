package concursodeexamenes.funciones;

import concursodeexamenes.BD.ConexionBD;
import concursodeexamenes.BD.Pregunta;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PreguntaDAO {

    public void crearTabla() {

        // El sistema si detecta que es vacío crea las tablas por sí solo

        String sql = """
        CREATE TABLE IF NOT EXISTS pregunta (
            id INT AUTO_INCREMENT PRIMARY KEY,
            modulo VARCHAR(50),
            unidad VARCHAR(10),
            numero VARCHAR(10),
            enunciado TEXT,
            correcta VARCHAR(255),
            incorrecta1 VARCHAR(255),
            incorrecta2 VARCHAR(255),
            incorrecta3 VARCHAR(255)
        );
    """;
        try (Connection conn = ConexionBD.conectar();
             Statement stmt = conn.createStatement()) {
            stmt.executeUpdate(sql);
        } catch (SQLException e) {
            System.err.println("Error creando tabla preguntas: " + e.getMessage());
        }
    }

    public static void insertarPregunta(Pregunta pregunta) {
        String sql = "INSERT INTO pregunta (modulo, unidad, numero, enunciado, correcta, incorrecta1, incorrecta2, incorrecta3) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = ConexionBD.conectar();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, pregunta.getModulo());
            stmt.setString(2, pregunta.getUnidad());
            stmt.setString(3, pregunta.getNumero());
            stmt.setString(4, pregunta.getEnunciado());
            stmt.setString(5, pregunta.getCorrecta());
            stmt.setString(6, pregunta.getIncorrecta1());
            stmt.setString(7, pregunta.getIncorrecta2());
            stmt.setString(8, pregunta.getIncorrecta3());
            stmt.executeUpdate();
        } catch (SQLException e) {
            System.err.println("Error insertando pregunta: " + e.getMessage());
        }
    }

    public void insertarPreguntas(List<Pregunta> preguntas) {
        for (Pregunta p : preguntas) {
            insertarPregunta(p);
        }
    }

    public List<Pregunta> obtenerPreguntas() {
        List<Pregunta> lista = new ArrayList<>();
        String sql = "SELECT * FROM Pregunta";

        try (Connection conn = ConexionBD.conectar();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                Pregunta p = new Pregunta(
                        rs.getString("modulo"),
                        rs.getString("unidad"),
                        rs.getString("numero"),
                        rs.getString("enunciado"),
                        rs.getString("correcta"),
                        rs.getString("incorrecta1"),
                        rs.getString("incorrecta2"),
                        rs.getString("incorrecta3")
                );
                lista.add(p);
            }
        } catch (SQLException e) {
            System.out.println("Error obteniendo preguntas: " + e.getMessage());
        }
        return lista;
    }

    public List<Pregunta> obtenerPreguntasFiltradas(String modulo, int unidad) {
        List<Pregunta> listaFiltrada = new ArrayList<>();
        for (Pregunta p : obtenerPreguntas()) {
            boolean moduloOK = modulo.equals("ALEATORIO") || p.getModulo().equalsIgnoreCase(modulo);
            boolean unidadOK = unidad == 0 || Integer.parseInt(p.getUnidad()) == unidad;
            if (moduloOK && unidadOK) listaFiltrada.add(p);
        }
        return listaFiltrada;
    }

    public List<Pregunta> obtenerTodas() {
        List<Pregunta> preguntas = new ArrayList<>();
        String sql = "SELECT * FROM pregunta";

        try (Connection conn = ConexionBD.conectar();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Pregunta p = new Pregunta(
                        rs.getString("modulo"),
                        rs.getString("unidad"),
                        rs.getString("numero"),
                        rs.getString("enunciado"),
                        rs.getString("correcta"),
                        rs.getString("incorrecta1"),
                        rs.getString("incorrecta2"),
                        rs.getString("incorrecta3")
                );
                preguntas.add(p);
            }

        } catch (SQLException e) {
            System.err.println("Error obteniendo preguntas: " + e.getMessage());
        }

        return preguntas;
    }

}
