package BD;

import java.sql.*;

public class ConexionBD {
    public static void main(String[] args) {
        // Parámetros de conexión
        String url = "jdbc:mysql://localhost:3306/testdb"; // Cambia testdb por el nombre de tu base
        String usuario = "root"; // Usuario de MySQL
        String contraseña = "1234"; // Pon tu contraseña

        try {
            // 1. Conexión a la base de datos
            Connection conexion = DriverManager.getConnection(url, usuario, contraseña);
            System.out.println("✅ Conectado a MySQL.");

            // 2. Crear tabla si no existe
            String crearTabla = "CREATE TABLE IF NOT EXISTS personas (" +
                    "id INT AUTO_INCREMENT PRIMARY KEY," +
                    "nombre VARCHAR(100)," +
                    "edad INT)";
            Statement stmt = conexion.createStatement();
            stmt.execute(crearTabla);
            System.out.println("📋 Tabla 'personas' lista.");

            // 3. Insertar un dato
            String insertar = "INSERT INTO personas (nombre, edad) VALUES (?, ?)";
            PreparedStatement insertarStmt = conexion.prepareStatement(insertar);
            insertarStmt.setString(1, "Juan");
            insertarStmt.setInt(2, 25);
            insertarStmt.executeUpdate();
            System.out.println("✅ Dato insertado.");



            String insertarPersona = "INSERT INTO PERSONAS (nombre, edad) VALUES (?, ?)";
            PreparedStatement Stmt1 = conexion.prepareStatement(insertarPersona);
            Stmt1.setString(1, "Ana");
            Stmt1.setInt(2, 26);
            Stmt1.executeUpdate();

            // 4. Leer y mostrar la tabla
            String consulta = "SELECT * FROM personas";
            ResultSet resultado = stmt.executeQuery(consulta);

            System.out.println("\n📄 CONTENIDO DE LA TABLA:");
            while (resultado.next()) {
                int id = resultado.getInt("id");
                String nombre = resultado.getString("nombre");
                int edad = resultado.getInt("edad");
                System.out.println("ID: " + id + ", Nombre: " + nombre + ", Edad: " + edad);
            }

            // 5. Cerrar conexión
            conexion.close();
            System.out.println("\n🔒 Conexión cerrada.");

        } catch (SQLException e) {
            System.out.println("❌ Error al conectar o ejecutar SQL.");
            e.printStackTrace();
        }
    }
}
