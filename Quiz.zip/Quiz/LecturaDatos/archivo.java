package LecturaDatos;

import java.io.*;
import java.util.*;

public class archivo {
    public static void main(String[] args) {
        // Ruta del archivo (puedes cambiar el nombre y carpeta)
        String rutaCarpeta = "Carpeta";
        String rutaArchivo = rutaCarpeta + "/archivo.txt";

        // Crear carpeta si no existe
        File carpeta = new File(rutaCarpeta);
        if (!carpeta.exists()) {
            carpeta.mkdirs();
            System.out.println("📁 Carpeta creada.");
        }

        // Crear archivo si no existe
        File archivo = new File(rutaArchivo);
        try {
            if (archivo.createNewFile()) {
                System.out.println("📄 Archivo creado.");
            } else {
                System.out.println("📄 El archivo ya existía.");
            }
        } catch (IOException e) {
            System.out.println("❌ Error al crear el archivo.");
            e.printStackTrace();
        }

        Scanner input = new Scanner(System.in);

        // Preguntar si se quiere sobrescribir o agregar texto
        System.out.print("\n¿Quieres sobrescribir (1) o agregar texto (2)? ");
        int opcion = input.nextInt();
        input.nextLine(); // limpiar buffer

        System.out.print("✍️ Escribe el texto a guardar: ");
        String texto = input.nextLine();

        // Escribir texto en el archivo
        try {
            FileWriter escritor;
            if (opcion == 1) {
                escritor = new FileWriter(archivo); // sobrescribe
            } else {
                escritor = new FileWriter(archivo, true); // agrega al final
            }
            escritor.write(texto + "\n");
            escritor.close();
            System.out.println("✅ Texto guardado correctamente.");
        } catch (IOException e) {
            System.out.println("❌ Error al escribir en el archivo.");
            e.printStackTrace();
        }

        System.out.println("\n📘 TIPOS DE LECTURA:\n");

        // 1. Leer línea por línea
        System.out.println("📌 Lectura línea por línea:");
        try (BufferedReader lector = new BufferedReader(new FileReader(archivo))) {
            String linea;
            while ((linea = lector.readLine()) != null) {
                System.out.println("> " + linea);
            }
        } catch (IOException e) {
            System.out.println("❌ Error al leer línea por línea.");
            e.printStackTrace();
        }

        // 2. Leer carácter por carácter
        System.out.println("\n📌 Lectura carácter por carácter:");
        try (FileReader lectorChar = new FileReader(archivo)) {
            int c;
            while ((c = lectorChar.read()) != -1) {
                System.out.print((char) c);
            }
        } catch (IOException e) {
            System.out.println("❌ Error al leer carácter por carácter.");
            e.printStackTrace();
        }

        // 3. Leer todo con Scanner
        System.out.println("\n\n📌 Lectura con Scanner:");
        try (Scanner sc = new Scanner(archivo)) {
            while (sc.hasNextLine()) {
                System.out.println("> " + sc.nextLine());
            }
        } catch (FileNotFoundException e) {
            System.out.println("❌ Error al usar Scanner.");
            e.printStackTrace();
        }

        input.close();
    }
}
