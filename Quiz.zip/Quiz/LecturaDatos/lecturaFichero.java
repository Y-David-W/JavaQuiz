package LecturaDatos;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class lecturaFichero {
    public static void main(String[] args) {
        int num = 123456789;
        File carpeta = new File("Carpeta");
        carpeta.mkdirs();
        File fichero = new File("Carpeta/prueba.txt");
        try {
            fichero.createNewFile();
            FileWriter escribir = new FileWriter(fichero);
            escribir.write(Integer.toString(num) + "\n");
            escribir.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

    }
}
