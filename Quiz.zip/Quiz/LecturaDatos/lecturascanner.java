package LecturaDatos;
import java.util.Scanner;
import java.io.File;

public class lecturascanner {
    public static void main(String[] args) {
        try {
            File f = new File("Carpeta/prueba.txt");
            Scanner lector = new Scanner(f);
            
            // Lee mientras haya números disponibles
            while (lector.hasNextInt()) {
                int valor = lector.nextInt();
                System.out.println("El valor leído es: " + valor);
            }
            
            lector.close();
        } catch (Exception e) {
            System.out.println("Error: " + e);
            e.printStackTrace();
        }
    }
}