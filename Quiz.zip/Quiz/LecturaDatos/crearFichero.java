package LecturaDatos;
import java.io.*;

public class crearFichero {
    public static void main(String[] args) {

        // CREA CARPET
        File carpeta = new File("Carpeta");
        carpeta.mkdirs();  // crea la carpeta si no existe (no importa si ya existe)

        File fichero = new File("Carpeta/prueba.txt");

        try {
            fichero.createNewFile(); // crea el archivo si no existe (si ya existe no hace nada)

            FileWriter escribir = new FileWriter(fichero);
            escribir.write("Hola mundo");
            escribir.close();

            System.out.println("Archivo creado y texto escrito.");

        } catch (IOException e) {
            e.printStackTrace();
        }



/*
        if (carpeta.delete()) {
            System.out.println("Carpeta eliminada.");
        } else {
            System.out.println("No se pudo eliminar la carpeta.");
        }
*/
    }
}
